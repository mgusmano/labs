Ext.define('AppCamp.view.Page05View', { extend: 'Ext.Container', xtype: 'page05view', html: 'page05view' });
