Ext.define('AppCamp.view.Page01View', { extend: 'Ext.Container', xtype: 'page01view', html: 'page01view' });
