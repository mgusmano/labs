Ext.define('AppCamp.view.Page07View', { extend: 'Ext.Container', xtype: 'page07view', html: 'page07view' });
