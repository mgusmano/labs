//@tag page02view
Ext.define('AppCamp.view.Page02View', { extend: 'Ext.Container', xtype: 'page02view', html: 'page02view' });
