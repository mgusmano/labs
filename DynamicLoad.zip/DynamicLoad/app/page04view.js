Ext.define('AppCamp.view.Page04View', { extend: 'Ext.Container', xtype: 'page04view', html: 'page04view' });
