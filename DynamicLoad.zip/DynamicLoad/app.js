Ext.application({ 
	name: 'AppCamp',
	extend: 'AppCamp.Application'
});
//https://www.sencha.com/blog/blazingly-fast-load-times-for-apps-built-with-ext-js-and-sencha-touch/
//http://docs-devel.sencha.com/extjs/4.2.2/#!/guide/command_app_multi
//http://docs.sencha.com/cmd/guides/advanced_cmd/cmd_compiler_reference.html