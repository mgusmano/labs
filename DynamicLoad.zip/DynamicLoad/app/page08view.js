Ext.define('AppCamp.view.Page08View', { extend: 'Ext.Container', xtype: 'page08view', html: 'page08view' });
