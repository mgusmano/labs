Ext.define('AppCamp.view.Page09View', { extend: 'Ext.Container', xtype: 'page09view', html: 'page09view' });
