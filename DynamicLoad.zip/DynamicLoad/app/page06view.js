Ext.define('AppCamp.view.Page06View', { extend: 'Ext.Container', xtype: 'page06view', html: 'page06view' });
